## Project Description
* Live Geometry lets you create interactive ruler and compass constructions and experiment with them. It is CAD-like educational software for teachers and students. It helps visualize and solve geometry problems.
* The project is written with Silverlight 4 and C# 4.0 (Visual Studio 2010). Visual Studio 2008 is no longer supported.
* The core engine is a flexible and extensible framework that allows you to easily add new figure types and features. The project has two front-ends: WPF and Silverlight; they both share the common DynamicGeometry library.
## Live Preview
Try the Drawing -> Samples button:
{silverlight:url=http://guilabs.de/geometry/LiveGeometry.xap,height=700,width=900}

## Links
* Play with it online: [http://livegeometry.com](http://livegeometry.com)
* My blog: [http://blogs.msdn.com/kirillosenkov](http://blogs.msdn.com/kirillosenkov)
* 5 min. Get Started video: [http://blogs.msdn.com/kirillosenkov/archive/2009/08/08/5-min-screencast-live-geometry-overview.aspx](http://blogs.msdn.com/kirillosenkov/archive/2009/08/08/5-min-screencast-live-geometry-overview.aspx)
* Overview article: [http://blogs.msdn.com/kirillosenkov/archive/2008/06/18/live-geometry-with-silverlight-2.aspx](http://blogs.msdn.com/kirillosenkov/archive/2008/06/18/live-geometry-with-silverlight-2.aspx)
* Introductory Coding4Fun article: [http://blogs.msdn.com/coding4fun/archive/2010/03/01/9971021.aspx](http://blogs.msdn.com/coding4fun/archive/2010/03/01/9971021.aspx)
## Releases and Downloads
To make sure only the up-to-date source code is available, I'm not publishing releases on the downloads tab. You can always download the latest source on the Source Code tab, just pick the recent changeset number and click Download to download the latest source.
You can view and use the application live at [http://livegeometry.com](http://livegeometry.com)
## [Documentation](Documentation)

## Screenshots
![](Home_screenshot.png)

![](Home_http://geometry.osenkov.com/screenshot.png)