﻿namespace DynamicGeometry
{
    public interface INumber : IFigure
    {
        double Value { get; }
    }
}