﻿namespace DynamicGeometry
{
    public interface ICommand
    {

    }
}
