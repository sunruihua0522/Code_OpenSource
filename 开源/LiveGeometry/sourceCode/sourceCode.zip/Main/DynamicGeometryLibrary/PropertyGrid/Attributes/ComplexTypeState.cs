﻿namespace DynamicGeometry
{
    public enum ComplexTypeState
    {
        Collapsed,
        Expanded
    }
}