﻿using System;

namespace DynamicGeometry
{
    public class ValidationException : Exception
    {
    }
}
