﻿namespace DynamicGeometry
{
    public interface IPropertyGridContentProvider
    {
        object GetContentForPropertyGrid();
    }
}
