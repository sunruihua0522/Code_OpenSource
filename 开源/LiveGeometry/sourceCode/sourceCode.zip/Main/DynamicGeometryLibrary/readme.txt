﻿Kirill Osenkov

http://www.livegeometry.com
http://livegeometry.codeplex.com/
http://blogs.msdn.com/b/KirillOsenkov
http://twitter.com/KirillOsenkov
http://undo.codeplex.com/
