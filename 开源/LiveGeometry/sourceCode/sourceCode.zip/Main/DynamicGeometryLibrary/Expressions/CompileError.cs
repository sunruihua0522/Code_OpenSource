﻿namespace DynamicGeometry
{
    public class CompileError
    {
        public string Text { get; set; }
        public int Position { get; set; }
    }
}
