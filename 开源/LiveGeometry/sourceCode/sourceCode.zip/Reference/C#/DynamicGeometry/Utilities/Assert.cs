﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynamicGeometry.Utilities
{
    public class Assert
    {
        public static void NotNull(object o)
        {
            if (o == null)
            {
                
            }
        }
    }
}
