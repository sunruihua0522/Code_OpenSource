﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows;

namespace DynamicGeometry
{
    //public class PointShape : ContentControl
    //{
    //    public PointShape()
    //    {
    //        int size = 8;
    //        Width = size;
    //        Height = size;

    //        Ellipse ellipse = new Ellipse()
    //        {
    //            Fill = new LinearGradientBrush(Colors.Yellow, Colors.White, 10),
    //            BitmapEffect = new DropShadowBitmapEffect()
    //            {
    //                ShadowDepth = 4,
    //                Opacity = 0.7
    //                //Softness = 0.5
    //            },
    //            Stroke = Brushes.Black,
    //            StrokeThickness = 0.5
    //        };

    //        Canvas.SetZIndex(ellipse, 10);
    //        Content = ellipse;
    //    }
    //}
}
