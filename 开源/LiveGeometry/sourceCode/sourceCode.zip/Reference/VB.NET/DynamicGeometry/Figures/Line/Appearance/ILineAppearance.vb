Imports GuiLabs.Canvas.DrawStyle

Friend Interface ILineAppearance

    Property LineStyle() As ILineStyleInfo

End Interface
