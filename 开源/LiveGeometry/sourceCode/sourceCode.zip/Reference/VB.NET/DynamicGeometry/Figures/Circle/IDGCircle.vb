Friend Interface IDGCircle
	Inherits IDGObject

	Property Center() As IDGPoint
	Property Radius() As Double

End Interface
