Public Class FigureCategoryStrings

	Public Const Point As String = "CategoryPoint"
	Public Const Line As String = "CategoryLine"
	Public Const Circle As String = "CategoryCircle"

End Class
