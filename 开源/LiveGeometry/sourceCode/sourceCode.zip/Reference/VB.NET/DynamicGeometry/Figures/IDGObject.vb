Imports GuiLabs.Canvas.Shapes

Friend Interface IDGObject

	Inherits IFigure
	Inherits IDrawable

	Function IsPointOver(ByVal x As Integer, ByVal y As Integer) As Boolean

End Interface
