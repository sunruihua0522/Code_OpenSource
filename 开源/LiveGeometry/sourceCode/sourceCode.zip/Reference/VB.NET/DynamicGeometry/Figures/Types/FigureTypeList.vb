'Friend Class FigureTypeList
'	Implements System.Collections.IEnumerable

'	Private list As ArrayList = New ArrayList()

'	Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
'		Return list.GetEnumerator
'	End Function

'	Public Sub Add(ByVal NewType As IFigureType)
'		list.Add(NewType)
'	End Sub

'	Public Function Count() As Integer
'		Return list.Count
'	End Function

'	Default Public Property Item(ByVal Index As Integer) As IFigureType
'		Get
'			Return DirectCast(list.Item(Index), IFigureType)
'		End Get
'		Set(ByVal Value As IFigureType)
'			list.Item(Index) = Value
'		End Set
'	End Property

'End Class
