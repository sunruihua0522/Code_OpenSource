'<AttributeUsage(AttributeTargets.Class)> Public Class FigureTypeAttribute
'	Inherits Attribute

'	Public Sub New(ByVal FigureTypeName As String, ByVal FigureTypeCategory As String)
'		mName = FigureTypeName
'		mCategory = FigureTypeCategory
'	End Sub

'	Private mName As String
'	Public Property Name() As String
'		Get
'			Return mName
'		End Get
'		Set(ByVal Value As String)
'			mName = Value
'		End Set
'	End Property

'	Private mCategory As String
'	Public Property Category() As String
'		Get
'			Return mCategory
'		End Get
'		Set(ByVal Value As String)
'			mCategory = Value
'		End Set
'	End Property

'End Class
