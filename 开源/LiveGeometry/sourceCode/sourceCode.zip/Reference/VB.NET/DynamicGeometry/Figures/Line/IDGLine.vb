Friend Interface IDGLine
	Inherits IDGObject

	Property P1() As IDGPoint
	Property P2() As IDGPoint

End Interface
