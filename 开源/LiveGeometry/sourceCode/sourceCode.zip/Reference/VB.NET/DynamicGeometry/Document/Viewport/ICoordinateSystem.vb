Friend Interface ICoordinateSystem

	Inherits ICoordinateTransformer

	ReadOnly Property Viewport() As MathTwoPoints
	ReadOnly Property ParentPlane() As IPlane

End Interface
