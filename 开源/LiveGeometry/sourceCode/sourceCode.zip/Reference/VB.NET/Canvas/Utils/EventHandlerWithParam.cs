using System;

namespace GuiLabs.Canvas.Utils
{
	public delegate void EventHandlerWithParam<T>(T param);
}
