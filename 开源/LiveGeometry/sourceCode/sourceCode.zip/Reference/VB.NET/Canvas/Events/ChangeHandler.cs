namespace GuiLabs.Canvas.Events
{
	public delegate void ChangeHandler<T> (T itemChanged);
}