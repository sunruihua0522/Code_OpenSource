#region Using directives

using GuiLabs.Canvas.Renderer;

#endregion

namespace GuiLabs.Canvas.Events
{
	//public interface IPaintHandler
	//{
	//    // TODO: Do we need this?
	//    void Paint(IRenderer Renderer);
	//}
}

