namespace GuiLabs.Canvas.Events
{
	public delegate void MouseWithKeysEventHandler(MouseEventArgsWithKeys MouseInfo);
}
