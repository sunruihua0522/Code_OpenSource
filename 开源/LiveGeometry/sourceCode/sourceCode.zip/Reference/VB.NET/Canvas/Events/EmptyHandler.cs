namespace GuiLabs.Canvas.Events
{
	public delegate void EmptyHandler();
}