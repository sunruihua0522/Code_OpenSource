Public Interface IMenuBuilder

	Function BuildMenu(ByVal MIFactory As ControlFactory) As System.Windows.Forms.MainMenu

End Interface
