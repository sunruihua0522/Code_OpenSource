Public Class CommandStrings

	Public Const File As String = "File"
	Public Const FileNew As String = "File.New"
	Public Const FileClose As String = "File.Close"
	Public Const FileExit As String = "File.Exit"

	Public Const Window As String = "Window"
	Public Const WindowCascade As String = "Window.Cascade"
	Public Const WindowTileHorizontal As String = "Window.TileHorizontal"
	Public Const WindowTileVertical As String = "Window.TileVertical"
	Public Const WindowArrange As String = "Window.Arrange"

End Class
