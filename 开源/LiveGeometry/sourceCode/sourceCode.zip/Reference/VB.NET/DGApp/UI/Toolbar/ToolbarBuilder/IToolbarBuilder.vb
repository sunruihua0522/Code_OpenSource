Public Interface IToolbarBuilder

	Function BuildToolbar(ByVal AppControlFactory As ControlFactory) As System.Windows.Forms.ToolBarButton()

End Interface
