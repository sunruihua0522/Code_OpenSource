Imports DynamicGeometry

Public Interface ICommandCarrier

	Property UICommand() As ICommand

End Interface
