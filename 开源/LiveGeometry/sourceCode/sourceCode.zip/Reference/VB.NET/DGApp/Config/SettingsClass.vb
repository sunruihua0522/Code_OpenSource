Public Class SettingsClass

	Public Class PathsClass
		Public ConfigFile As String
	End Class

	Public Paths As PathsClass = New PathsClass()

End Class
