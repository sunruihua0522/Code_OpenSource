Public Module modSettings

	Public Settings As SettingsClass = New SettingsClass()

End Module